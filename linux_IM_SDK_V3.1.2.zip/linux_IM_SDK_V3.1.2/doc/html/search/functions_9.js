var searchData=
[
  ['latestmessage',['latestMessage',['../classeasemob_1_1EMConversation.html#addb8b868bb5a83f92f9cf26ee36e98d9',1,'easemob::EMConversation']]],
  ['latestmessagefromothers',['latestMessageFromOthers',['../classeasemob_1_1EMConversation.html#a2a5ecabfec844a287d35de984df173ba',1,'easemob::EMConversation']]],
  ['latitude',['latitude',['../classeasemob_1_1EMLocationMessageBody.html#ab80e9842fafc5df088515c550d59301e',1,'easemob::EMLocationMessageBody']]],
  ['leavechatroom',['leaveChatroom',['../classeasemob_1_1EMChatroomManagerInterface.html#a01186f69303dacbb3f7cc4020e25b6b3',1,'easemob::EMChatroomManagerInterface']]],
  ['leavegroup',['leaveGroup',['../classeasemob_1_1EMGroupManagerInterface.html#a535ee092e9d8b1c2409cc8c0153f1fb8',1,'easemob::EMGroupManagerInterface']]],
  ['loadallconversationsfromdb',['loadAllConversationsFromDB',['../classeasemob_1_1EMChatManagerInterface.html#a93d17500e351723956bdb49530c4437d',1,'easemob::EMChatManagerInterface']]],
  ['loadallmygroupsfromdb',['loadAllMyGroupsFromDB',['../classeasemob_1_1EMGroupManagerInterface.html#a13fb039c866d4e03a39bcf5ff853cd9a',1,'easemob::EMGroupManagerInterface']]],
  ['loadmessage',['loadMessage',['../classeasemob_1_1EMConversation.html#aa17d8fb2c8ba4b3bde2614f24ea62b20',1,'easemob::EMConversation']]],
  ['loadmoremessages',['loadMoreMessages',['../classeasemob_1_1EMConversation.html#a083365dac723b508de85e5dac832f392',1,'easemob::EMConversation::loadMoreMessages(const std::string &amp;refMsgId, int count, EMMessageSearchDirection direction=UP)'],['../classeasemob_1_1EMConversation.html#a183b64bde16ab46d1150fd5ffdb22360',1,'easemob::EMConversation::loadMoreMessages(int64_t timeStamp, int count, EMMessageSearchDirection direction=UP)'],['../classeasemob_1_1EMConversation.html#a1a5824ad1bfd22c79c66a1d09139e9ee',1,'easemob::EMConversation::loadMoreMessages(EMMessageBody::EMMessageBodyType type, int64_t timeStamp=-1, int count=-1, const std::string &amp;from=&quot;&quot;, EMMessageSearchDirection direction=UP)'],['../classeasemob_1_1EMConversation.html#a38177c4655d05bee589aacdd73a7d274',1,'easemob::EMConversation::loadMoreMessages(const std::string &amp;keywords, int64_t timeStamp=-1, int count=-1, const std::string &amp;from=&quot;&quot;, EMMessageSearchDirection direction=UP)'],['../classeasemob_1_1EMConversation.html#ace8b268b70f3f6259b9f0e51850f54ae',1,'easemob::EMConversation::loadMoreMessages(int64_t startTimeStamp, int64_t endTimeStamp, int maxCount)']]],
  ['localpath',['localPath',['../classeasemob_1_1EMFileMessageBody.html#a0d90572dd7529f7693c917c19a9aa09b',1,'easemob::EMFileMessageBody']]],
  ['login',['login',['../classeasemob_1_1EMClient.html#a82b1f812d679b40c546fb17eef9a7225',1,'easemob::EMClient']]],
  ['logout',['logout',['../classeasemob_1_1EMClient.html#a84d162e2efe3dc02f9191315e0331565',1,'easemob::EMClient']]],
  ['longitude',['longitude',['../classeasemob_1_1EMLocationMessageBody.html#aa818596c01fe85ed7f986d69da336467',1,'easemob::EMLocationMessageBody']]]
];
