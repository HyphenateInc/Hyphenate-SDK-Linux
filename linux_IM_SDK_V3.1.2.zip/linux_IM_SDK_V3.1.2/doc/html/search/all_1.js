var searchData=
[
  ['blacklist',['blacklist',['../classeasemob_1_1EMContactManagerInterface.html#a24d3466f86908f6152f06bfde24b8dc5',1,'easemob::EMContactManagerInterface']]],
  ['blockgroupmembers',['blockGroupMembers',['../classeasemob_1_1EMGroupManagerInterface.html#a61a13d0d2b19e3963a20678eb3f16010',1,'easemob::EMGroupManagerInterface']]],
  ['blockgroupmessage',['blockGroupMessage',['../classeasemob_1_1EMGroupManagerInterface.html#a677a66ccfc96466a4f0a72b5e3f2fb6b',1,'easemob::EMGroupManagerInterface']]],
  ['bodies',['bodies',['../classeasemob_1_1EMMessage.html#acfeaaa7da54962929ff77b8453fc0945',1,'easemob::EMMessage']]]
];
