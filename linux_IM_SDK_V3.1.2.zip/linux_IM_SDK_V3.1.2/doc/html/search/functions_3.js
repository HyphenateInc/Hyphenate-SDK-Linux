var searchData=
[
  ['declineinvitation',['declineInvitation',['../classeasemob_1_1EMContactManagerInterface.html#ac9c0236b17d05007c05133777378540a',1,'easemob::EMContactManagerInterface']]],
  ['declineinvitationfromgroup',['declineInvitationFromGroup',['../classeasemob_1_1EMGroupManagerInterface.html#acde37047346395ed2b2c2e937055d36c',1,'easemob::EMGroupManagerInterface']]],
  ['declinejoingroupapplication',['declineJoinGroupApplication',['../classeasemob_1_1EMGroupManagerInterface.html#a5b95a82a26bef39d9077d84b258a191f',1,'easemob::EMGroupManagerInterface']]],
  ['decrypt',['decrypt',['../classeasemob_1_1EMEncryptProviderInterface.html#a3f99c9612c20f1912e0507c61cc93a46',1,'easemob::EMEncryptProviderInterface']]],
  ['deletecontact',['deleteContact',['../classeasemob_1_1EMContactManagerInterface.html#aea3fa55787ab17531ed571940e4d74fe',1,'easemob::EMContactManagerInterface']]],
  ['destroygroup',['destroyGroup',['../classeasemob_1_1EMGroupManagerInterface.html#a599ca5ffdfd6e3762660aebb330916f3',1,'easemob::EMGroupManagerInterface']]],
  ['displayname',['displayName',['../classeasemob_1_1EMFileMessageBody.html#a265146240d700a440a099abc5d9233b4',1,'easemob::EMFileMessageBody']]],
  ['downloadmessageattachments',['downloadMessageAttachments',['../classeasemob_1_1EMChatManagerInterface.html#af3c167ba29a841f243bcbfcbbca5723c',1,'easemob::EMChatManagerInterface']]],
  ['downloadmessagethumbnail',['downloadMessageThumbnail',['../classeasemob_1_1EMChatManagerInterface.html#acaa1c0edaa738a6d96516d2fa1f4a411',1,'easemob::EMChatManagerInterface']]],
  ['downloadstatus',['downloadStatus',['../classeasemob_1_1EMFileMessageBody.html#a7f068aaf37c986a87be5d8b77ef96029',1,'easemob::EMFileMessageBody']]],
  ['dummy',['dummy',['../classeasemob_1_1EMMessageBody.html#a69c4434e6f0c89e5f5987fa29c6f62f6',1,'easemob::EMMessageBody']]],
  ['duration',['duration',['../classeasemob_1_1EMVideoMessageBody.html#a690df040068a2c490b14f9a8ad714912',1,'easemob::EMVideoMessageBody::duration()'],['../classeasemob_1_1EMVoiceMessageBody.html#a23968f4c5a581f1cb240655c235fa35e',1,'easemob::EMVoiceMessageBody::duration()']]]
];
