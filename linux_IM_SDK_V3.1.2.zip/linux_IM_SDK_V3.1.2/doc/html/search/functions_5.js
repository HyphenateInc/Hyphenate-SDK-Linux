var searchData=
[
  ['fetchallchatrooms',['fetchAllChatrooms',['../classeasemob_1_1EMChatroomManagerInterface.html#a1b21532d7f71ef2ca756d2ba3541fdc9',1,'easemob::EMChatroomManagerInterface']]],
  ['fetchallmygroups',['fetchAllMyGroups',['../classeasemob_1_1EMGroupManagerInterface.html#a1cf76f208208777fa89876d88270672a',1,'easemob::EMGroupManagerInterface']]],
  ['fetchchatroomspecification',['fetchChatroomSpecification',['../classeasemob_1_1EMChatroomManagerInterface.html#a6e3dbca7ccad80fe3fcd2b51b7333565',1,'easemob::EMChatroomManagerInterface']]],
  ['fetchchatroomswithcursor',['fetchChatroomsWithCursor',['../classeasemob_1_1EMChatroomManagerInterface.html#a45c395ea74b0930cb19ebcf938455b5a',1,'easemob::EMChatroomManagerInterface']]],
  ['fetchgroupbans',['fetchGroupBans',['../classeasemob_1_1EMGroupManagerInterface.html#ac6540fb2eb95153429769e4299ffeaf2',1,'easemob::EMGroupManagerInterface']]],
  ['fetchgroupspecification',['fetchGroupSpecification',['../classeasemob_1_1EMGroupManagerInterface.html#ad62a42bdf238b609c8e15bfd059ff565',1,'easemob::EMGroupManagerInterface']]],
  ['fetchpublicgroupswithcursor',['fetchPublicGroupsWithCursor',['../classeasemob_1_1EMGroupManagerInterface.html#a5a968d1818f80cfa0d25ec4e9823012c',1,'easemob::EMGroupManagerInterface']]],
  ['filelength',['fileLength',['../classeasemob_1_1EMFileMessageBody.html#a5e95c4cca4b6257f3889c853d2e01ba9',1,'easemob::EMFileMessageBody']]],
  ['from',['from',['../classeasemob_1_1EMMessage.html#a1d865957addc78a8fb217b030669fb20',1,'easemob::EMMessage']]]
];
