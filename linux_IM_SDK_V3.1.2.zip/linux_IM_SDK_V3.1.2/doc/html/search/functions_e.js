var searchData=
[
  ['registercontactlistener',['registerContactListener',['../classeasemob_1_1EMContactManagerInterface.html#af9215e0c289b78d5d9c2287d471e783b',1,'easemob::EMContactManagerInterface']]],
  ['remotepath',['remotePath',['../classeasemob_1_1EMFileMessageBody.html#a41ec423b6abe4eb5cc4a55264d4c6e72',1,'easemob::EMFileMessageBody']]],
  ['removeattribute',['removeAttribute',['../classeasemob_1_1EMMessage.html#aa415571801043b9a91828ca94a1f60b9',1,'easemob::EMMessage']]],
  ['removeconnectionlistener',['removeConnectionListener',['../classeasemob_1_1EMClient.html#a17f75ff708aed69ee5bf0fdb258f1acd',1,'easemob::EMClient']]],
  ['removecontactlistener',['removeContactListener',['../classeasemob_1_1EMContactManagerInterface.html#a5275f6820ceac8a6f8516518639a9635',1,'easemob::EMContactManagerInterface']]],
  ['removeconversation',['removeConversation',['../classeasemob_1_1EMChatManagerInterface.html#a787750008e60086c8759a491e65cc721',1,'easemob::EMChatManagerInterface']]],
  ['removefromblacklist',['removeFromBlackList',['../classeasemob_1_1EMContactManagerInterface.html#a428e3f62622534579416484f84f1cb05',1,'easemob::EMContactManagerInterface']]],
  ['removegroupmembers',['removeGroupMembers',['../classeasemob_1_1EMGroupManagerInterface.html#a258cc8478093fd29e3182dde4289ebff',1,'easemob::EMGroupManagerInterface']]],
  ['removelistener',['removeListener',['../classeasemob_1_1EMChatManagerInterface.html#aabcbb389ad6275fb4f46d7f5b2b0253a',1,'easemob::EMChatManagerInterface::removeListener()'],['../classeasemob_1_1EMChatroomManagerInterface.html#ae66e64b5baf7c849d282aa0822b67da0',1,'easemob::EMChatroomManagerInterface::removeListener()'],['../classeasemob_1_1EMGroupManagerInterface.html#aebee356adc3b3910c64c3240f97b2f5a',1,'easemob::EMGroupManagerInterface::removeListener()']]],
  ['removemessage',['removeMessage',['../classeasemob_1_1EMConversation.html#a64e5895444d323d60e3f317b63732edc',1,'easemob::EMConversation::removeMessage(const std::string &amp;msgId)'],['../classeasemob_1_1EMConversation.html#afe011fe6061dfa6c1045eaa27ebaf820',1,'easemob::EMConversation::removeMessage(const EMMessagePtr msg)']]],
  ['resendmessage',['resendMessage',['../classeasemob_1_1EMChatManagerInterface.html#ad5daeec09558c88c4d268f85f7b5efc9',1,'easemob::EMChatManagerInterface']]],
  ['result',['result',['../classeasemob_1_1EMCursorResult.html#a672843b03f91af735237fa0689b9ed53',1,'easemob::EMCursorResult']]]
];
