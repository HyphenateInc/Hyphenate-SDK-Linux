var searchData=
[
  ['markallmessagesasread',['markAllMessagesAsRead',['../classeasemob_1_1EMConversation.html#ac818f535bb913df485f817923f932535',1,'easemob::EMConversation']]],
  ['markmessageasread',['markMessageAsRead',['../classeasemob_1_1EMConversation.html#aa0dc3061be94c058e43051f65ff92bb4',1,'easemob::EMConversation']]],
  ['messagescount',['messagesCount',['../classeasemob_1_1EMConversation.html#a32a17541ed2cb095fb001cb4b0e92350',1,'easemob::EMConversation']]],
  ['msgdirection',['msgDirection',['../classeasemob_1_1EMMessage.html#a59c1a17a92542bf3cc2898e5072bbefb',1,'easemob::EMMessage']]],
  ['msgid',['msgId',['../classeasemob_1_1EMMessage.html#a896bc765b3b072c2ad433750faad7685',1,'easemob::EMMessage']]]
];
